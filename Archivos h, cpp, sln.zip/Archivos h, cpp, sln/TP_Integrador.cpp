#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include "Crosshair.h"
#include "Enemigo.h"
#include "Inocente.h"
#include "Bar.h"
#include "Texto.h"
#include "Pantallas.h"

using namespace sf;

int main() {
    RenderWindow App(VideoMode(1400, 800), "Gang Mode");
    Event evt;
    Enemigo enemigo;
    Inocente inocentes;
    Crosshair crosshair;
    Bar bar;
    Texto texto;
    Clock timer;
    Pantallas pantallas;
    const Time tiempoLimite = seconds(3.0f);
    srand((time(NULL)));
    App.setMouseCursorVisible(false);
    int enemigosEliminados = 0;
    int vidasRestantes = 3;
    int inocentesEliminados = 0;
    int Puntaje = 0;
    bool mostrarSprite = false;
    bool mostrarBang = false;
    bool restarVidas = false;
    pantallas.mostrarInstrucciones(App);
    enemigo.posEnemigo();
    inocentes.posInocentes();
    texto.actTexto(enemigosEliminados, vidasRestantes);

    while (App.isOpen() && vidasRestantes > 0 && enemigosEliminados < 10) {
        while (App.pollEvent(evt)) {
            if (evt.type == Event::Closed)
                App.close();
            else if (evt.type == Event::MouseButtonPressed && evt.mouseButton.button == Mouse::Left) {
                int mouseX = evt.mouseButton.x;
                int mouseY = evt.mouseButton.y;
                int probabilidad = rand() % 3;
                if (probabilidad <= 1) {
                    mostrarSprite = true;
                    if (enemigo.click(mouseX, mouseY)) {
                        enemigo.posEnemigo();
                        enemigosEliminados++;
                        timer.restart();
                        if (restarVidas) {
                            vidasRestantes--;
                            restarVidas = false;
                        }
                    }
                }
                else {
                    mostrarSprite = false;
                    if (inocentes.click(mouseX, mouseY)) {
                        vidasRestantes--;
                        inocentes.posInocentes();
                        inocentesEliminados++;
                        timer.restart();
                    }
                }
                texto.actTexto(enemigosEliminados, vidasRestantes);
            }
        }
        App.clear();
        App.draw(bar.getFondo());
        if (mostrarSprite) {
            enemigo.drawEnemigo(App);
        }
        else {
            inocentes.draw(App);
        }
        if (timer.getElapsedTime() > tiempoLimite) {
            if (mostrarSprite) {
                mostrarBang = true;
                timer.restart();
                mostrarSprite = false;
            }
            else {
                mostrarBang = false;
                timer.restart();
                mostrarSprite = true;
            }
        }
        if (mostrarBang) {
            enemigo.drawBang(App);
            restarVidas = true;
        }
        App.draw(bar.getFrente());
        crosshair.posCrosshair(Mouse::getPosition(App).x, Mouse::getPosition(App).y);
        App.draw(crosshair.getCrosshair());
        texto.draw(App);
        App.display();
    }
    Puntaje = enemigosEliminados - (10 * inocentesEliminados);
    pantallas.mostrarPantallaFinal(App, Puntaje);

    return 0;
}