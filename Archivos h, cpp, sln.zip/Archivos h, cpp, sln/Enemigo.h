#pragma once
#include <SFML/Graphics.hpp>
using namespace sf;

class Enemigo {
public:
    Enemigo();
    void posEnemigo();
    void drawBang(RenderWindow& App);
    void drawEnemigo(RenderWindow& App);
    bool click(int mouseX, int mouseY);
private:
    Texture texturaBang;
    Sprite spriteBang;
    Texture texturaEnemigo1;
    Texture texturaEnemigo2;
    Texture texturaEnemigo3;
    Sprite spriteEnemigo;
};