#include "Enemigo.h"

Enemigo::Enemigo() {
    if (!texturaEnemigo1.loadFromFile("enemigo1.png")) {}
    if (!texturaEnemigo2.loadFromFile("enemigo2.png")) {}
    if (!texturaEnemigo3.loadFromFile("enemigo3.png")) {}
    if (!texturaBang.loadFromFile("bang.png")) {}
    spriteBang.setTexture(texturaBang);
    spriteBang.setScale(0.5f, 0.5f);
    spriteBang.setPosition(610, 370);
}

void Enemigo::posEnemigo() {
    int posiciones = rand() % 5;
    switch (posiciones) {
    case 0:
        spriteEnemigo.setTexture(texturaEnemigo2);
        spriteEnemigo.setScale(0.2f, 0.2f);
        spriteEnemigo.setPosition(170, 30);
        break;
    case 1:
        spriteEnemigo.setTexture(texturaEnemigo3);
        spriteEnemigo.setScale(0.2f, 0.2f);
        spriteEnemigo.setPosition(980, 50);
        break;
    case 2:
        spriteEnemigo.setTexture(texturaEnemigo2);
        spriteEnemigo.setScale(0.2f, 0.2f);
        spriteEnemigo.setPosition(170, 400);
        break;
    case 3:
        spriteEnemigo.setTexture(texturaEnemigo3);
        spriteEnemigo.setScale(0.2f, 0.2f);
        spriteEnemigo.setPosition(980, 430);
        break;
    case 4:
        spriteEnemigo.setTexture(texturaEnemigo1);
        spriteEnemigo.setScale(0.3f, 0.3f);
        spriteEnemigo.setPosition(610, 430);
        break;
    }
}

void Enemigo::drawEnemigo(RenderWindow& App) {
    App.draw(spriteEnemigo);
}

void Enemigo::drawBang(RenderWindow& App) {
    App.draw(spriteBang);
}

bool Enemigo::click(int mouseX, int mouseY) {
    return spriteEnemigo.getGlobalBounds().contains(mouseX, mouseY);
}