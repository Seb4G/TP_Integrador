#include "Crosshair.h"
using namespace sf;

Crosshair::Crosshair() {
    if (!texturaCrosshair.loadFromFile("crosshair.png")) {}
    spriteCrosshair.setTexture(texturaCrosshair);
    spriteCrosshair.setOrigin(600, 600);
    spriteCrosshair.setPosition(600, 400);
    spriteCrosshair.setScale(0.1f, 0.1f);
}
Sprite Crosshair::getCrosshair() {
    return spriteCrosshair;
}
void Crosshair::posCrosshair(float x, float y) {
    spriteCrosshair.setPosition(x, y);
}