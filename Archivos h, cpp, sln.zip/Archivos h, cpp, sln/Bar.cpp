#include "Bar.h"
using namespace sf;

Bar::Bar() {
    if (!texturaFondo.loadFromFile("Fondo.png")) {}
    spriteFondo.setTexture(texturaFondo);
    if (!texturaFrente.loadFromFile("Frente.png")) {}
    spriteFrente.setTexture(texturaFrente);
}
Sprite Bar::getFondo() {
    return spriteFondo;
}
Sprite Bar::getFrente() {
    return spriteFrente;
}