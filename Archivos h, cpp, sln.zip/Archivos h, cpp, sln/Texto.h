#pragma once
#include <SFML/Graphics.hpp>
using namespace sf;
using namespace std;

class Texto {
public:
    Texto();
    void actTexto(int enemigosEliminados, int vidasRestantes);
    void draw(RenderWindow& App);
private:
    Font font;
    Text textoEnemigosEliminados;
    Text textoVidasRestantes;
};