#include "Texto.h"

Texto::Texto() {
    if (!font.loadFromFile("fuente.TTF")) {}

    textoEnemigosEliminados.setFont(font);
    textoEnemigosEliminados.setPosition(30, 730);
    textoEnemigosEliminados.setCharacterSize(40);
    textoEnemigosEliminados.setFillColor(Color::Magenta);

    textoVidasRestantes.setFont(font);
    textoVidasRestantes.setPosition(900, 730);
    textoVidasRestantes.setCharacterSize(40);
    textoVidasRestantes.setFillColor(Color::Magenta);
}
void Texto::actTexto(int aliensEliminados, int vidasRestantes) {
    textoEnemigosEliminados.setString("Enemigos eliminados: " + to_string(aliensEliminados));
    textoVidasRestantes.setString("Vidas restantes: " + to_string(vidasRestantes));

}
void Texto::draw(RenderWindow& App) {
    App.draw(textoEnemigosEliminados);
    App.draw(textoVidasRestantes);
}