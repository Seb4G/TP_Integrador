#include "Pantallas.h"

Pantallas::Pantallas() {
    if (!font.loadFromFile("fuente.TTF")) {}
    textoInstrucciones.setFont(font);
    textoInstrucciones.setPosition(20, 20);
    textoInstrucciones.setCharacterSize(40);
    textoInstrucciones.setFillColor(Color::Magenta);

    textoPuntaje.setFont(font);
    textoPuntaje.setCharacterSize(80);
    textoPuntaje.setPosition(270, 650);
    textoPuntaje.setFillColor(Color::Magenta);
    textoPuntaje.setPosition(270, 650);

    if (!texturaGameOver.loadFromFile("gameover.png")) {}
    spriteGameOver.setTexture(texturaGameOver);
    spriteGameOver.setPosition(300, 30);
}
void Pantallas::mostrarPantallaFinal(RenderWindow& App, int puntaje) {
    textoPuntaje.setString("Puntaje Final: " + to_string(puntaje));
    while (App.isOpen()) {
        Event evt;
        while (App.pollEvent(evt)) {
            if (evt.type == Event::Closed) {
                App.close();
            }
        }
        App.clear();
        App.draw(spriteGameOver);
        App.draw(textoPuntaje);
        App.display();
    }
}
bool Pantallas::mostrarInstrucciones(RenderWindow& App) {
    textoInstrucciones.setString("TIROTEO ROB�TICO\n\nINSTRUCCIONES:\n\n- Se apunta y dispara con el puntero del rat�n\n\n- Cada disparo acertado a un enemigo suma 1 punto\n\n- Cada disparo acertado a un inocente resta una vida\n\n- Si el enemigo dispara resta una vida\n\n- Se gana matando 10 enemigos\n\n-Se pierde si gastamos 3 vidas\n\n-Puntaje es igual a enemigos abaitdos - inocentes x 10\n\nDISPARA PARA EMPEZAR EL JUEGO");

    App.clear();
    App.draw(textoInstrucciones);
    App.display();

    Event evt;
    while (App.isOpen()) {
        while (App.pollEvent(evt)) {
            if (evt.type == sf::Event::Closed) {
                App.close();
                return false;
            }
            else if (evt.type == sf::Event::MouseButtonPressed && evt.mouseButton.button == sf::Mouse::Left) {
                return true;
            }
        }
    }
    return false;
}
