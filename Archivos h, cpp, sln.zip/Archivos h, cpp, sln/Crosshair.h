#pragma once
#include <SFML/Graphics.hpp>
using namespace sf;

class Crosshair {
public:
    Crosshair();
    Sprite getCrosshair();
    void posCrosshair(float x, float y);

private:
    Texture texturaCrosshair;
    Sprite spriteCrosshair;
};