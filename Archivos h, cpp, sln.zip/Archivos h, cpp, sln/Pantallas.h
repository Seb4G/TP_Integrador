#pragma once
#include <SFML/Graphics.hpp>
using namespace sf;
using namespace std;

class Pantallas {
public:
    Pantallas();
    void mostrarPantallaFinal(RenderWindow& App, int puntaje);
    bool mostrarInstrucciones(RenderWindow& App);
private:
    Font font;
    Texture texturaGameOver;
    Sprite spriteGameOver;
    Text textoPuntaje;
    Text textoInstrucciones;
};