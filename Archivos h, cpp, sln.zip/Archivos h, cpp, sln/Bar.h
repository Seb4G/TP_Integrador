#pragma once
#include <SFML/Graphics.hpp>
using namespace sf;

class Bar {
public:
    Bar();
    Sprite getFondo();
    Sprite getFrente();

private:
    Texture texturaFondo;
    Sprite spriteFondo;
    Texture texturaFrente;
    Sprite spriteFrente;
};