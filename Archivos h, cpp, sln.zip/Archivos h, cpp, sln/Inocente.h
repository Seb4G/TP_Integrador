#pragma once
#include <SFML/Graphics.hpp>
using namespace sf;

class Inocente {
public:
    Inocente();
    void draw(RenderWindow& App);
    void posInocentes();
    bool click(int mouseX, int mouseY);

private:
    Texture texturaInocente;
    Sprite spriteInocente;
};


