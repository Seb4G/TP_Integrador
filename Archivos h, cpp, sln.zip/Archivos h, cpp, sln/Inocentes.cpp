#include "Inocente.h"

Inocente::Inocente() {
    if (!texturaInocente.loadFromFile("inocente.png")) {}
    spriteInocente.setTexture(texturaInocente);
    spriteInocente.setScale(0.2f, 0.2f);
}
void Inocente::draw(RenderWindow& App) {
    App.draw(spriteInocente);
}
void Inocente::posInocentes() {
    int posiciones = rand() % 4;
    switch (posiciones) {
    case 0:
        spriteInocente.setPosition(155, 30);
        break;
    case 1:
        spriteInocente.setPosition(1015, 30);
        break;
    case 2:
        spriteInocente.setPosition(155, 400);
        break;
    case 3:
        spriteInocente.setPosition(1015, 400);
        break;
    }
}
bool Inocente::click(int mouseX, int mouseY) {
    return spriteInocente.getGlobalBounds().contains(mouseX, mouseY);
}